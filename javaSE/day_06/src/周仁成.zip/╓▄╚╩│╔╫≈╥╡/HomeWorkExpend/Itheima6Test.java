package HomeWorkExpend;

public class Itheima6Test {
    public static void main(String[] args) {

        Itheima6 itheima6=new Itheima6();
        int sum=itheima6.sum();
        System.out.println(sum);
    }
}
